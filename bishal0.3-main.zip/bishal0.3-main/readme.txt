For Animation :
1. Locomotive
2. Gsap
3. SeryJS


